PROMPT =======================================================
PROMPT 5.	List the names and seniority date (date hired) of 
PROMPT all faculty.
PROMPT =======================================================

-- finding where the truncate can be and not be when using RPAD was a struggle...
-- Had to use a trunk and TO_CHAR for SENORITY_DATE to properly format with the RPAD.
-- Otherwise the leading '.' had a lot of space to the right.
-- RTRIM was not removing the space either, nor LTRIM on the DATE.
-- For such a small script, comparable to the previous questions, this took the longest to figure out. 

COLUMN "Employee" FORMAT A35
COLUMN "Hiring Date" FORMAT A11

SELECT RPAD(FIRSTNAME || ' ' || SURNAME, 35, '.') AS "Employee", TO_CHAR(SENIORITY_DATE) AS "Hiring Date"
FROM FACULTY
ORDER BY SENIORITY_DATE;