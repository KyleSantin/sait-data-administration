PROMPT =======================================================
PROMPT 10. List each student, id and name, and the overall 
PROMPT (in other words: normal, regular, typical, mean) 2010 
PROMPT grade for that student where the student has taken 2 
PROMPT or more courses in the year 2010. 
PROMPT =======================================================

-- "overall" suggests to me that I'll be using a SUM for GRADE
-- which means it cannot be used in the SELECT with single-group functions

-- question asks for year 2010 but there is no 2010 data in the datatable.
-- ive changed the result to be 2025 so i can see some sort of result

-- removed the BREAK ON formating as it was interfering with the output
-- GROUP BY is pretty much doing the same thing as BREAK ON but more
-- using GROUP BY and clumping the student into lets me us COUNT on
-- the rows rather than specifying the grades

-- TO_CHAR the AVG so I could format left-aligned

COLUMN SURNAME FORMAT A15 HEADING "Last Name"
COLUMN FIRSTNAME FORMAT A15 HEADING "First Name"
COLUMN STUDENT_ID FORMAT A15 HEADING "Student ID"
COLUMN "GPA" FORMAT A6

SELECT s.SURNAME,
       s.FIRSTNAME,
       s.STUDENT_ID,
       TO_CHAR(ROUND(AVG(c.GRADE), 2)) AS "GPA"
FROM STUDENT s
JOIN COURSE_REGISTRATION c
  ON s.STUDENT_ID = c.STUDENT_ID
WHERE c.YEAR = '2025'
GROUP BY s.SURNAME, s.FIRSTNAME, s.STUDENT_ID
HAVING COUNT(*) >= 2
ORDER BY s.SURNAME, s.FIRSTNAME;
