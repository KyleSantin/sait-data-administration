PROMPT =======================================================
PROMPT 8. List the name of the faculty (person or persons) 
PROMPT having the same birthday (month and day)
PROMPT (not birthdate, month, day, and year) as Harry Hilbert. 
PROMPT =======================================================

-- FACULTY TABLE ( FIRSTNAME, SURNAME, BIRTHDATE)

/* Template to use - Very basic setup
Let's build from this and the WHERE clause after FROM
SELECT FIRSTNAME, SURNAME, BIRTHDATE
FROM FACULTY
WHERE [logic]
ORDER BY BIRTHDATE;
*/

-- USE WHERE INSTEAD OF HAVING. HAVING IS USED FOR GROUPINGS OR AGGREGATES SUCH AS SUM AND AVG

COLUMN FIRSTNAME FORMAT A11 HEADING "First Name"
COLUMN SURNAME FORMAT A11 HEADING "Last Name"
COLUMN BIRTHDATE FORMAT A14 HEADING "Date of Birth"

SELECT FIRSTNAME, SURNAME, BIRTHDATE
FROM FACULTY
WHERE TO_CHAR(BIRTHDATE, 'MMDD') = (
    SELECT TO_CHAR(BIRTHDATE, 'MMDD')
    FROM FACULTY
    WHERE FIRSTNAME = 'Harry' AND SURNAME = 'Hilbert'
) 
AND NOT (FIRSTNAME = 'Harry' AND SURNAME = 'Hilbert')
ORDER BY FIRSTNAME;