PROMPT =======================================================
PROMPT 11. List all faculty members by name and id, and where 
PROMPT appropriate list the course code and level for all
PROMPT courses in which they have expertise.  The output
PROMPT should be similar in appearance to that shown below.  
PROMPT =======================================================

-- FACULTY TABLE | SURNAME, FIRSTNAME, EMPLOYEE_ID
-- EXPERTISE TABLE | EMPLOEE_ID, EXPERTISE_LEVEL

COLUMN SURNAME FORMAT A15 HEADING "Last Name"
COLUMN FIRSTNAME FORMAT A15 HEADING "First Name"
COLUMN COURSE_CODE FORMAT A15 HEADING "Course Code"
COLUMN "Expertise Level" FORMAT A15

BREAK ON EMPLOYEE_ID ON SURNAME ON FIRSTNAME

SELECT f.EMPLOYEE_ID, f.SURNAME, f.FIRSTNAME, e.COURSE_CODE, TO_CHAR(e.EXPERTISE_LEVEL) AS "Expertise Level"
FROM FACULTY f
JOIN EXPERTISE e
ON f.EMPLOYEE_ID = e.EMPLOYEE_ID
ORDER BY f.SURNAME;