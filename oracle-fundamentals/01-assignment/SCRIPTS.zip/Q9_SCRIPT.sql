PROMPT =======================================================
PROMPT 9. What is the average age of all faculty excluding 
PROMPT deans?  Deans do not belong to any unit although they 
PROMPT may manage one. 
PROMPT =======================================================

-- was trying to use AVG(SYSDATE - BIRTHDATE) but came across some issues
-- more research let me find the FLOOR clause
-- You can use a MONTHS_BETWEEN()/12 to put it in years
-- But that will return a table to ages, I still need to AVG them

-- I can use AVG within the FLOOR Clause and remove SURNAME/FIRSTNAME 
-- since they will not work with an AVG in the same SELECT.

-- COLUMN formatting is producing ##### as a age result and not what I want
-- Had to clear the column with "CLEAR COLUMN" to delete any caches
-- the FORMAT 99 CENTER - specifically CENTER is used for characters not numbers

-- Cannot format with COLUMN AVERAGE_AGE FORMAT A15 HEADING "AVERAGE AGE"
-- it goes back to producing ##### - Need to format within the SELECT
-- this actually makes it look cleaner. To center the number output looks
-- like more trouble than it should be. I'll leave it as is.

-- Added TO_CHAR for formating. Without it the output is right aligned, but
-- with TO_CHAR it is left aligned. I then have to add COLUMN Axx formating
-- to improve the format

COLUMN "Average Age" FORMAT A12

SELECT TO_CHAR(FLOOR(AVG(MONTHS_BETWEEN(SYSDATE, BIRTHDATE)/12))) AS "Average Age"
FROM FACULTY
WHERE UNIT IS NOT NULL;