PROMPT =======================================================
PROMPT 2. List all teaching faculty by name and the courses 
PROMPT (code and course title) that they teach. Each instructor 
PROMPT course combination should be listed only once.  
PROMPT =======================================================

COLUMN SURNAME FORMAT A10 HEADING "  SURNAME  "
COLUMN FIRSTNAME FORMAT A15 HEADING "   FIRSTNAME   "
COLUMN COURSE_CODE FORMAT A15 HEADING "   COURSE_CO   "
COLUMN COURSE_TITLE FORMAT A25 WORD_WRAPPED HEADING "     COURSE_TITLE     "

BREAK ON SURNAME ON FIRSTNAME SKIP 1

SELECT DISTINCT f.SURNAME, f.FIRSTNAME, c.COURSE_CODE, c.COURSE_TITLE
FROM FACULTY f
INNER JOIN CLASS_SECTION cs
ON f.EMPLOYEE_ID = cs.INSTRUCTOR_ID
INNER JOIN COURSE c
ON cs.COURSE_CODE = c.COURSE_CODE
ORDER BY f.SURNAME, f.FIRSTNAME, c.COURSE_CODE, c.COURSE_TITLE;