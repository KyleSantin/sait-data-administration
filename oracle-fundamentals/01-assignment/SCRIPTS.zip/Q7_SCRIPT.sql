PROMPT =======================================================
PROMPT 7. List each faculty member, id and name, and the 
PROMPT number of days that faculty member has been employed 
PROMPT by ICCC.  List those faculty members with the 
PROMPT most seniority first.  
PROMPT =======================================================

-- copied Q5, removed the truncation and TO_CHAR.
-- added the ROUND and SYSDATE logic

COLUMN FIRSTNAME FORMAT A12 HEADING "First Name"
COLUMN SURNAME FORMAT A12 HEADING "Last Name"
COLUMN EMPLOEE_ID FORMAT 999999999 HEADING "Employee ID"
COLUMN EMPLOYEMENT_DAYS FORMAT 9999 HEADING "Employement Days"

SELECT FIRSTNAME, SURNAME, EMPLOYEE_ID, ROUND(SYSDATE - SENIORITY_DATE) as EMPLOYEMENT_DAYS
FROM FACULTY
ORDER BY EMPLOYEMENT_DAYS DESC;