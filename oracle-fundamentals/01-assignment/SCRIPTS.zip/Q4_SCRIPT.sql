PROMPT =======================================================
PROMPT 4. The faculty member whose ID is 002300137 is going 
PROMPT away for a year on sabbatical.  The administration wants 
PROMPT to know who can cover any classes that this individual 
PROMPT has expertise in.  List the employee id, name and subject 
PROMPT code for all employees who are qualified to teach a course
PROMPT that 002300137 can teach.  Do not concern yourself with 
PROMPT comparative expertise levels. 
PROMPT =======================================================

-- You cannot use "" when using numbers, need to use single quotations

COLUMN EMPLOYEE_ID FORMAT A11 HEADING "Employee ID"
COLUMN SURNAME FORMAT A10 HEADING "Last Name"
COLUMN FIRSTNAME FORMAT A15 HEADING "First Name"
COLUMN COURSE_CODE FORMAT A12 HEADING "Course Code"

BREAK ON EMPLOYEE_ID ON SURNAME ON FIRSTNAME

SELECT f.EMPLOYEE_ID, f.SURNAME, f.FIRSTNAME, e.COURSE_CODE
FROM FACULTY f
JOIN EXPERTISE e
ON e.EMPLOYEE_ID = f.EMPLOYEE_ID
WHERE e.COURSE_CODE IN (SELECT COURSE_CODE FROM EXPERTISE WHERE EMPLOYEE_ID = '002300137')
AND f.EMPLOYEE_ID != '002300137'
ORDER BY f.EMPLOYEE_ID;