PROMPT =======================================================
PROMPT 3. List the name and id of all students registered in 
PROMPT a course in which no mark has yet been issued.    
PROMPT =======================================================

-- not sure why only COURSE_CODE was not fitting even when increasing the A#.
-- manually formatted the heading to force it
-- have to find the null or '' empty space
-- I looked into the datatables and noticed there is no null
-- WHERE TRIM(GRADE) = ' '; would satisfy the question alone without mention of null.
-- it would be proper to include NULL aswell as ' '

COLUMN STUDENT_ID FORMAT A10 HEADING "STUDENT_ID"
COLUMN SURNAME FORMAT A10 HEADING "SURNAME"
COLUMN FIRSTNAME FORMAT A12 HEADING "FIRSTNAME"
COLUMN COURSE_CODE FORMAT A15 HEADING "COURSE_CODE"

SELECT s.STUDENT_ID, s.SURNAME, s.FIRSTNAME, c.COURSE_CODE
FROM STUDENT s
JOIN COURSE_REGISTRATION c
ON s.STUDENT_ID = c.STUDENT_ID
WHERE GRADE IS NULL OR TRIM(GRADE) = ' '
ORDER BY s.STUDENT_ID;