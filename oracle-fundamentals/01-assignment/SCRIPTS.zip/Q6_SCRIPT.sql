PROMPT =======================================================
PROMPT 6. Faculty members, excluding deans, must pay 0.7% of 
PROMPT their salary in union dues. List each faculty member, 
PROMPT id and name, and the amount that must be deducted for 
PROMPT dues each month.  Exclude deans from this listing.  
PROMPT Deans, and only deans, do not belong to any unit. 
PROMPT =======================================================

COLUMN NAME FORMAT A20
COLUMN UNION_DUES FORMAT $99,999.99 HEADING "UNION DUES"

SELECT RPAD(f.FIRSTNAME || ' ' || f.SURNAME, 20, ' ') AS NAME, ROUND(f.SALARY * 0.007 / 12, 2) AS UNION_DUES
FROM FACULTY F
JOIN ORGANIZATIONAL_UNIT o
ON o.UNIT_SUPERVISOR = f.EMPLOYEE_ID
WHERE o.UNIT_SUPERVISOR IS NOT NULL
ORDER BY f.SURNAME;
